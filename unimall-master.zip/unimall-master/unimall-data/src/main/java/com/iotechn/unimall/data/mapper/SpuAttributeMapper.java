package com.iotechn.unimall.data.mapper;

import com.dobbinsoft.fw.support.mapper.IMapper;
import com.iotechn.unimall.data.domain.SpuAttributeDO;

/**
 * Created by rize on 2019/7/2.
 */
public interface SpuAttributeMapper extends IMapper<SpuAttributeDO> {
}
