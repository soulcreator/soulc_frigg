package com.iotechn.unimall.data.mapper;


import com.iotechn.unimall.data.domain.RolePermissionDO;
import com.dobbinsoft.fw.support.mapper.IMapper;

/**
 * Created by rize on 2019/7/8.
 */
public interface RolePermissionMapper extends IMapper<RolePermissionDO> {
}
