package com.iotechn.unimall.data.mapper;

import com.dobbinsoft.fw.support.mapper.IMapper;
import com.iotechn.unimall.data.domain.VipOrderDO;

public interface VipOrderMapper extends IMapper<VipOrderDO> {
}
