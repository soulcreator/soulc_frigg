package com.iotechn.unimall.data.mapper;

import com.dobbinsoft.fw.support.mapper.IMapper;
import com.iotechn.unimall.data.domain.AddressDO;

/*
@author kbq
@date  2019/7/4 - 22:09
*/
public interface AddressMapper extends IMapper<AddressDO> {
}
