package com.iotechn.unimall.data.mapper;

import com.iotechn.unimall.data.domain.RoleDO;
import com.dobbinsoft.fw.support.mapper.IMapper;

/**
 * Created by rize on 2019/7/8.
 */
public interface RoleMapper extends IMapper<RoleDO> {
}
