package com.iotechn.unimall.data.mapper;

import com.dobbinsoft.fw.support.mapper.IMapper;
import com.iotechn.unimall.data.domain.SkuActivityPriceDO;

/**
 * Description:
 * User: rize
 * Date: 2020/8/4
 * Time: 15:06
 */
public interface SkuActivityPriceMapper extends IMapper<SkuActivityPriceDO> {
}
