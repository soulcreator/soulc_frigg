package com.iotechn.unimall.data.mapper;

import com.iotechn.unimall.data.domain.DynamicConfigDO;
import com.dobbinsoft.fw.support.mapper.IMapper;

/**
 * ClassName: DynamicConfigMapper
 * Description: TODO
 *
 * @author: e-weichaozheng
 * @date: 2021-03-17
 */
public interface DynamicConfigMapper extends IMapper<DynamicConfigDO> {
}
