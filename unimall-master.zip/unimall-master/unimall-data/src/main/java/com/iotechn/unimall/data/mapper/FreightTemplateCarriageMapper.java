package com.iotechn.unimall.data.mapper;

import com.dobbinsoft.fw.support.mapper.IMapper;
import com.iotechn.unimall.data.domain.FreightTemplateCarriageDO;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: kbq
 * Date: 2019-07-07
 * Time: 下午3:28
 */
public interface FreightTemplateCarriageMapper extends IMapper<FreightTemplateCarriageDO> {
}
