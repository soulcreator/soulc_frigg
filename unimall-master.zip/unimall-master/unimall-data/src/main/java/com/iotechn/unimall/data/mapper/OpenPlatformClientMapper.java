package com.iotechn.unimall.data.mapper;

import com.iotechn.unimall.data.domain.OpenPlatformClientDO;
import com.dobbinsoft.fw.support.mapper.IMapper;

/**
 * ClassName: OpenPlatformMapper
 * Description: TODO
 *
 * @author: e-weichaozheng
 * @date: 2021-04-25
 */
public interface OpenPlatformClientMapper extends IMapper<OpenPlatformClientDO> {
}
