package com.iotechn.unimall.data.dto;

import lombok.Data;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: rize
 * Date: 2020/3/11
 * Time: 12:50
 */
@Data
public class CodeReverseGenerateTableDTO {

    private String name;

    private boolean exist;

}
