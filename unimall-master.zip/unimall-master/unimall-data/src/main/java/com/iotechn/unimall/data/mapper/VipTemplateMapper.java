package com.iotechn.unimall.data.mapper;

import com.dobbinsoft.fw.support.mapper.IMapper;
import com.iotechn.unimall.data.domain.VipTemplateDO;

public interface VipTemplateMapper extends IMapper<VipTemplateDO> {




}
