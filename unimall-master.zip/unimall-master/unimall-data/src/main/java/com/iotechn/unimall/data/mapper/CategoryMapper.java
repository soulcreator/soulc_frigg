package com.iotechn.unimall.data.mapper;

import com.dobbinsoft.fw.support.mapper.IMapper;
import com.iotechn.unimall.data.domain.CategoryDO;

/**
 * Created by rize on 2019/7/2.
 */
public interface CategoryMapper extends IMapper<CategoryDO> {



}
