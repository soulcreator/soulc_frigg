package com.iotechn.unimall.data.mapper;

import com.iotechn.unimall.data.domain.AdminLogDO;
import com.dobbinsoft.fw.support.mapper.IMapper;

/**
 * Description:
 * User: rize
 * Date: 2020/8/11
 * Time: 16:09
 */
public interface AdminLogMapper extends IMapper<AdminLogDO> {

}
