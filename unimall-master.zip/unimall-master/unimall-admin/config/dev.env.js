module.exports = {
	NODE_ENV: '"development"',
  ENV_CONFIG: '"dev"',
  HOST: '"http://localhost:8081"'
}
