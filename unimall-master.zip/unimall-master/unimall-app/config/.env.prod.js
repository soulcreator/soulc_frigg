const config = {
    baseUrl: 'https://unimall.v3.dobbinsoft.com',
    h5Appid: 'wxb66b599f7f61b46f',
    debug: false,
    OSS_PROVIDER: 'qcloud'
}
module.exports = config