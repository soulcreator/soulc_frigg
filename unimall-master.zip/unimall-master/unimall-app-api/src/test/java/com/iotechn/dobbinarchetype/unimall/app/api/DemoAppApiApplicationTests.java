package com.iotechn.dobbinarchetype.unimall.app.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAppApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
