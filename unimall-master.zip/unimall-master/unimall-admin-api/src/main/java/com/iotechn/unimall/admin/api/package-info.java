/**
 * 描述: Spring组件<br>
 * 项目名称: data_collection_error_info_transformation <br>
 * 创建时间: 2020/5/6 12:59 <br>
 * 公司信息: 凯通科技股份有限公司 产品研发中心-大数据产品<br>
 *
 * @version v1.0
 */
package com.iotechn.unimall.admin.api;
